#Cassandra Jugaste 10IT
#Filmigeneraator?
#Kasutaja soovib filmi vaadata, tal on olemas vaatamata filmide nimekirjad, kuid ei suuda otsustada, millist vaadata. Programm aitab filmi valida.
#Filminimekirjad guugeldades "Top 10 " " movies in 2016", Google'i top 10, valitud nii, et filmid ei korduks.
import random
#---------------------------------------------------------------------------------------------------------------------------------------------------
muutuja = int(input("Mitut filmi soovite vaadata? "))
#---------------------------------------------------------------------------------------------------------------------------------------------------
kategooria = input("Sisestage filmi kategooria (action, horror, comedy, thriller, romance): ")
if kategooria == "action":
    f = open("action.txt", encoding = "UTF-8-SIG")
elif kategooria == "horror":
    f = open("horror.txt", encoding = "UTF-8-SIG")
elif kategooria == "comedy":
    f = open("comedy.txt", encoding = "UTF-8-SIG")
elif kategooria == "thriller":
    f = open("thriller.txt", encoding = "UTF-8-SIG")
elif kategooria == "romance":
    f = open("romance.txt", encoding = "UTF-8-SIG")
else:
    print("Vale sisestus.")
#---------------------------------------------------------------------------------------------------------------------------------------------------
def valib(mitu):
    järjend = []
    valik = []
    for rida in f: 
        järjend.append(rida.strip())
    while mitu > 0:
        suvaline = random.randint(0, mitu)
        valik.append(järjend[suvaline])
        järjend.remove(järjend[suvaline])
        mitu -= 1
    return valik
#---------------------------------------------------------------------------------------------------------------------------------------------------
if muutuja < 0:
    print("Vale sisestus.")
elif muutuja > 9:
    print("Vale sisestus.")
else:
    print("Filmisoovitus(ed): ")
    for i in valib(muutuja):
        print(i)
f.close()